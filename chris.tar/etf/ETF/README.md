# ETF
Scrapes data from financial sites and imports it into excel 

Scrapes ETF data from:
  ETF.com
  Maxfunds.com
  Smartmoney.com 
  
